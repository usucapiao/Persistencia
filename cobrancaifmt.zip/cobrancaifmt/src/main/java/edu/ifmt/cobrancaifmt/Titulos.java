package edu.ifmt.cobrancaifmt;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.ifmt.cobrancaifmt.model.Titulo;

public interface Titulos extends JpaRepository<Titulo, Long> {

}
